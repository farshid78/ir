package ir.recorder;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;
import android.content.Context;
import android.database.Cursor;
import android.provider.OpenableColumns;
import java.io.*;

public class MainActivity extends Activity {
    private static final int CREATE_FILE = 41;
    private TextView status;
    private CheckBox includeLabels;
    @Override public void onCreate(Bundle b) { super.onCreate(b);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28,28,28,28); root.setBackgroundColor(0xFFF7F8FA);
        TextView title = new TextView(this); title.setText("ثبت‌گر مستقل رابط ایرانسل"); title.setTextSize(23); title.setTextColor(0xFF14243A); root.addView(title);
        TextView desc = new TextView(this); desc.setText("این برنامه جدا از بسته‌یاب است. فقط رویدادها و ساختار رابط کاربری بستهٔ com.myirancell را، آن هم در زمان ثبت دستی، ذخیره می‌کند. هیچ لمس یا عملی را خودش اجرا نمی‌کند."); desc.setTextSize(15); desc.setPadding(0,18,0,18); root.addView(desc);
        includeLabels = new CheckBox(this); includeLabels.setText("ثبت برچسب‌های متنی غیرحساس (اختیاری؛ متن‌های شبیه شماره، رمز، کد و مبلغ حذف می‌شوند)"); includeLabels.setChecked(false); root.addView(includeLabels);
        Button access = button("۱) بازکردن تنظیمات دسترس‌پذیری"); root.addView(access); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        Button start = button("۲) شروع ثبت؛ سپس ایرانسل من را باز کن"); root.addView(start); start.setOnClickListener(v -> { getSharedPreferences(RecorderService.PREF,0).edit().putBoolean("recording",true).putBoolean("labels",includeLabels.isChecked()).apply(); RecorderService.newSession(this); status.setText("ثبت فعال شد. حالا ایرانسل من را باز کن و همان مسیر مشکل‌دار را یک بار انجام بده."); });
        Button stop = button("توقف ثبت"); root.addView(stop); stop.setOnClickListener(v -> { getSharedPreferences(RecorderService.PREF,0).edit().putBoolean("recording",false).apply(); status.setText("ثبت متوقف شد."); });
        Button export = button("ذخیره و خروجی گرفتن از گزارش JSONL"); root.addView(export); export.setOnClickListener(v -> exportLog());
        status = new TextView(this); status.setText("وضعیت: آماده"); status.setTextSize(15); status.setPadding(0,22,0,12); root.addView(status);
        TextView note = new TextView(this); note.setText("محدودیت مهم: اندروید اجازهٔ شنود عمومی مختصات خام همهٔ لمس‌ها را به سرویس دسترس‌پذیری نمی‌دهد. این ابزار رویداد کلیک/فوکوس/اسکرول، اندازه و مختصات گره‌های رابط، شناسهٔ View، کلاس، ترتیب رویدادها و نتیجهٔ اقدام‌های قابل مشاهده را ثبت می‌کند. از صفحه‌نمایش، رمز، پیامک، شماره و موجودی عکس یا متن خام ذخیره نمی‌کند."); note.setTextSize(13); note.setTextColor(0xFF555F6B); note.setPadding(0,12,0,0); root.addView(note);
        setContentView(root);
    }
    private Button button(String s) { Button b=new Button(this); b.setText(s); return b; }
    private void exportLog() { Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/x-ndjson"); i.putExtra(Intent.EXTRA_TITLE,"irancell-ui-session.jsonl"); startActivityForResult(i,CREATE_FILE); }
    @Override protected void onActivityResult(int req,int res,Intent data) { super.onActivityResult(req,res,data); if(req==CREATE_FILE && res==RESULT_OK && data!=null && data.getData()!=null) { try(InputStream in=openFileInput(RecorderService.LOG); OutputStream out=getContentResolver().openOutputStream(data.getData())) { byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n); status.setText("گزارش ذخیره شد."); } catch(Exception e) { status.setText("خطا در خروجی: "+e.getClass().getSimpleName()); } } }
}
