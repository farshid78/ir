package ir.recorder;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import org.json.JSONObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class RecorderService extends AccessibilityService {
    static final String PREF="recorder_prefs", LOG="irancell-session.jsonl", TARGET="com.myirancell";
    private static final Pattern SENSITIVE=Pattern.compile("(?i)(\\+?98|0)?9\\d{9}|\\b\\d{4,}\\b|رمز|یکبار|otp|password|کارت|موجودی");
    private long lastTree=0; private int sequence=0;
    static void newSession(Context c) { try { c.openFileOutput(LOG,Context.MODE_PRIVATE).close(); } catch(Exception ignored){} }
    @Override protected void onServiceConnected() { AccessibilityServiceInfo i=getServiceInfo(); i.eventTypes=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED|AccessibilityEvent.TYPE_WINDOWS_CHANGED|AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED|AccessibilityEvent.TYPE_VIEW_CLICKED|AccessibilityEvent.TYPE_VIEW_FOCUSED|AccessibilityEvent.TYPE_VIEW_SELECTED|AccessibilityEvent.TYPE_VIEW_SCROLLED|AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUSED|AccessibilityEvent.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED; i.flags|=AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS|AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS|AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS; setServiceInfo(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) {
        if(e==null || !getSharedPreferences(PREF,0).getBoolean("recording",false)) return;
        CharSequence p=e.getPackageName(); if(p==null || !TARGET.contentEquals(p)) return;
        JSONObject o=base("event"); put(o,"eventType",AccessibilityEvent.eventTypeToString(e.getEventType())); put(o,"eventTime",e.getEventTime()); put(o,"class",str(e.getClassName())); put(o,"windowId",e.getWindowId()); put(o,"fromIndex",e.getFromIndex()); put(o,"toIndex",e.getToIndex()); put(o,"itemCount",e.getItemCount()); put(o,"scrollX",e.getScrollX()); put(o,"scrollY",e.getScrollY()); put(o,"maxScrollX",e.getMaxScrollX()); put(o,"maxScrollY",e.getMaxScrollY()); AccessibilityNodeInfo src=e.getSource(); if(src!=null) { Rect sb=new Rect(); src.getBoundsInScreen(sb); put(o,"sourceClass",str(src.getClassName())); put(o,"sourceViewId",str(src.getViewIdResourceName())); put(o,"sourceBounds",rect(sb)); put(o,"sourceClickable",src.isClickable()); put(o,"sourceScrollable",src.isScrollable()); }
        if(getSharedPreferences(PREF,0).getBoolean("labels",false)) put(o,"safeEventText",safe(e.getText()==null?"":e.getText().toString())); append(o);
        long now=System.currentTimeMillis(); if(now-lastTree>500 || e.getEventType()==AccessibilityEvent.TYPE_VIEW_SCROLLED || e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) { lastTree=now; captureWindows(); }
    }
    private void captureWindows() { List<AccessibilityWindowInfo> ws=getWindows(); if(ws==null) return; int wi=0; for(AccessibilityWindowInfo w:ws) { if(w==null) continue; AccessibilityNodeInfo r=w.getRoot(); if(r==null) continue; CharSequence rp=r.getPackageName(); if(rp==null || !TARGET.contentEquals(rp)) continue; Rect b=new Rect(); w.getBoundsInScreen(b); JSONObject o=base("window"); put(o,"windowIndex",wi++); put(o,"windowType",w.getType()); put(o,"layer",w.getLayer()); put(o,"active",w.isActive()); put(o,"focused",w.isFocused()); put(o,"bounds",rect(b)); append(o); walk(r,0,new int[]{0}); } }
    private void walk(AccessibilityNodeInfo n,int depth,int[] count) { if(n==null || depth>18 || count[0]>=700) return; count[0]++; Rect b=new Rect(); n.getBoundsInScreen(b); JSONObject o=base("node"); put(o,"depth",depth); put(o,"class",str(n.getClassName())); put(o,"viewId",str(n.getViewIdResourceName())); put(o,"bounds",rect(b)); put(o,"clickable",n.isClickable()); put(o,"longClickable",n.isLongClickable()); put(o,"scrollable",n.isScrollable()); put(o,"focusable",n.isFocusable()); put(o,"focused",n.isFocused()); put(o,"enabled",n.isEnabled()); put(o,"visible",n.isVisibleToUser()); put(o,"checkable",n.isCheckable()); put(o,"checked",n.isChecked()); put(o,"childCount",n.getChildCount()); if(getSharedPreferences(PREF,0).getBoolean("labels",false)) { put(o,"text",safe(str(n.getText()))); put(o,"description",safe(str(n.getContentDescription()))); } append(o); for(int x=0;x<n.getChildCount() && count[0]<700;x++) { AccessibilityNodeInfo c=n.getChild(x); if(c!=null) walk(c,depth+1,count); } }
    private JSONObject base(String type) { JSONObject o=new JSONObject(); put(o,"schema",1); put(o,"kind",type); put(o,"seq",++sequence); put(o,"time",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ",Locale.US).format(new Date())); put(o,"package",TARGET); DisplayMetrics m=getResources().getDisplayMetrics(); put(o,"screenWidthPx",m.widthPixels); put(o,"screenHeightPx",m.heightPixels); put(o,"density",m.density); put(o,"densityDpi",m.densityDpi); put(o,"scaledDensity",m.scaledDensity); put(o,"sdk",Build.VERSION.SDK_INT); return o; }
    private String rect(Rect r) { return r.left+","+r.top+","+r.right+","+r.bottom; }
    private String str(CharSequence s) { return s==null?"":s.toString(); }
    private String safe(String s) { if(s==null || s.isEmpty()) return ""; if(SENSITIVE.matcher(s).find()) return "[REDACTED]"; return s.length()>100? s.substring(0,100):s; }
    private void put(JSONObject o,String k,Object v) { try{o.put(k,v);}catch(Exception ignored){} }
    private synchronized void append(JSONObject o) { try(FileOutputStream f=openFileOutput(LOG,MODE_APPEND)) { f.write((o.toString()+"\n").getBytes("UTF-8")); } catch(Exception ignored){} }
    @Override public void onInterrupt() { }
}
